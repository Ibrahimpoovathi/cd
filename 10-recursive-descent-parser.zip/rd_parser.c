#include <stdio.h>
#include <string.h>

char s[20];
int i = 0, error = 0;

void E();
void T();
void F();

void E() {
    T();
    while (s[i] == '+') {
        i++;
        T();
    }
}

void T() {
    F();
    while (s[i] == '*') {
        i++;
        F();
    }
}

void F() {
    if (s[i] == 'a')
        i++;
    else if (s[i] == '(') {
        i++;
        E();
        if (s[i] == ')')
            i++;
        else
            error = 1;
    }
    else
        error = 1;
}

int main() {
    printf("Enter expression: ");
    scanf("%s", s);
    E();
    if (i == strlen(s) && error == 0)
        printf("Accepted");
    else
        printf("Rejected");
    return 0;
}